# DBMS-Income-Tax-Management-System

Project is according to the Indian Tax Regime in the years 2020-21

The project uses Pyhton and MySQL 

There is a menu ofchoices for user (like insert record, update record, delete record, get taxable income, etc.)
<br/>
<br/>![Screenshot (266)](https://user-images.githubusercontent.com/70025630/135745897-f7331add-d045-4f3d-8ebe-19c1bd9d2c28.png)

